import os
import tkinter as tk
from tkinter import messagebox, ttk
import application

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


class AppHelha:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("HELHA.net")
        self.root.geometry("900x560")
        self.root.resizable(False, False)
        self.root.configure(bg="#FFFFFF")

        try:
            self.logo_img  = tk.PhotoImage(file=os.path.join(BASE_DIR, "logo.png"))
            self.logoMenu2 = tk.PhotoImage(file=os.path.join(BASE_DIR, "logoMenu2.png"))
        except Exception:
            self.logo_img  = None
            self.logoMenu2 = None

        try:
            self.root.iconbitmap(os.path.join(BASE_DIR, "icone.ico"))
        except Exception:
            pass

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview",
                        background="#FFFFFF", fieldbackground="#FFFFFF",
                        rowheight=28, font=("Segoe UI", 10))
        style.configure("Treeview.Heading",
                        background="#1A56DB", foreground="white",
                        font=("Segoe UI", 10, "bold"))
        style.map("Treeview",
                  background=[("selected", "#1A56DB")],
                  foreground=[("selected", "#FFFFFF")])

        self.user_nom  = None
        self.user_role = None
        self._afficher_demarrage()


    #  UTILITAIRES UI
    def _clear(self):
        for w in self.root.winfo_children():
            w.destroy()

    def _clear_zone(self):
        for w in self.zone.winfo_children():
            w.destroy()

    def _panel_gauche(self, texte=""):
        side = tk.Frame(self.root, bg="#2C7CF6", width=420, height=560)
        side.pack(side="left", fill="both")
        side.pack_propagate(False)
        if self.logo_img:
            tk.Label(side, image=self.logo_img, bg="#2C7CF6").pack(anchor="w", padx=40, pady=(60, 16))
        else:
            tk.Label(side, text="HELHA", fg="white", bg="#2C7CF6",
                     font=("Segoe UI", 22, "bold")).pack(anchor="w", padx=40, pady=(60, 16))
        tk.Frame(side, bg="white", width=60, height=3).pack(anchor="w", padx=40)
        if texte:
            tk.Label(side, text=texte, fg="white", bg="#2C7CF6",
                     justify="left", font=("Segoe UI", 11)).pack(anchor="w", padx=40, pady=30)
        return side

    @staticmethod
    def _btn(parent, texte, cmd, couleur="#1A56DB", **kw):
        return tk.Button(parent, text=texte, bg=couleur, fg="white",
                         font=("Segoe UI", 11, "bold"), relief="flat",
                         activebackground="#1240A8", activeforeground="white",
                         cursor="hand2", command=cmd, **kw)

    @staticmethod
    def _champ(parent, show=None, width=None):
        """
        Champ de saisie VISIBLE sur Windows.
        Retourne (frame_a_packer, entry).
        Le Frame gris sert de bordure ; le Entry blanc est dedans.
        """
        kw = {}
        if show   is not None: kw["show"]  = show
        if width  is not None: kw["width"] = width

        border = tk.Frame(parent, bg="#94A3B8", padx=2, pady=2)
        inner  = tk.Frame(border, bg="#FFFFFF")
        inner.pack(fill="both", expand=True)
        entry  = tk.Entry(inner, bg="#FFFFFF", fg="#111827",
                          insertbackground="#111827",
                          relief="flat", font=("Segoe UI", 12),
                          highlightthickness=0, bd=0, **kw)
        entry.pack(fill="both", expand=True, padx=6, pady=6)

        def focus_in(e):  border.config(bg="#2C7CF6")
        def focus_out(e): border.config(bg="#94A3B8")
        entry.bind("<FocusIn>",  focus_in)
        entry.bind("<FocusOut>", focus_out)

        return border, entry

    @staticmethod
    def _lbl(parent, texte, bg="#FFFFFF"):
        tk.Label(parent, text=texte, bg=bg, fg="#6B7280",
                 font=("Segoe UI", 10)).pack(anchor="w", padx=50)

    
    #  AUTHENTIFICATION
    def _afficher_demarrage(self):
        if application.est_premier_lancement():
            self._afficher_setup()
            return
        self._clear()
        self._panel_gauche("Cette application permet de gérer\nvos configurations réseaux\nde manière simplifiée et sécurisée.")

        form = tk.Frame(self.root, bg="#FFFFFF", width=480, height=560)
        form.pack(side="right", fill="both", expand=True)
        form.pack_propagate(False)

        tk.Label(form, text="Identifiez-vous.", fg="#1F2937", bg="#FFFFFF",
                 font=("Segoe UI", 22, "bold")).pack(anchor="w", padx=50, pady=(70, 30))

        self._lbl(form, "Nom d'utilisateur")
        f1, self.ent_nom = self._champ(form)
        f1.pack(fill="x", padx=50, pady=(4, 16))

        self._lbl(form, "Mot de passe")
        f2, self.ent_mdp = self._champ(form, show="*")
        f2.pack(fill="x", padx=50, pady=(4, 28))

        self._btn(form, "Se connecter", self._connexion).pack(padx=50, fill="x", ipady=10)
        self.ent_mdp.bind("<Return>", lambda e: self._connexion())

    def _afficher_setup(self):
        self._clear()
        self._panel_gauche("Premier lancement détecté.\nVeuillez créer le compte\nadministrateur principal.")

        form = tk.Frame(self.root, bg="#FFFFFF", width=480, height=560)
        form.pack(side="right", fill="both", expand=True)
        form.pack_propagate(False)

        tk.Label(form, text="Installation.", fg="#1F2937", bg="#FFFFFF",
                 font=("Segoe UI", 22, "bold")).pack(anchor="w", padx=50, pady=(70, 30))

        self._lbl(form, "Nom d'utilisateur Admin")
        f1, self.ent_setup_nom = self._champ(form)
        f1.pack(fill="x", padx=50, pady=(4, 16))

        self._lbl(form, "Mot de passe")
        f2, self.ent_setup_mdp = self._champ(form, show="*")
        f2.pack(fill="x", padx=50, pady=(4, 28))

        self._btn(form, "Activer le système", self._finaliser_setup).pack(padx=50, fill="x", ipady=10)

    def _finaliser_setup(self):
        nom = self.ent_setup_nom.get().strip()
        mdp = self.ent_setup_mdp.get()
        if not nom or not mdp:
            messagebox.showwarning("Erreur", "Champs obligatoires.")
            return
        application.sauvegarde_admin_initial(nom, mdp)
        messagebox.showinfo("Succès", "Administrateur créé !")
        self._afficher_demarrage()

    def _connexion(self):
        statut, role, must_change = application.connexion(
            self.ent_nom.get(), self.ent_mdp.get()
        )
        if statut == "ok":
            self.user_nom  = self.ent_nom.get()
            self.user_role = role
            if must_change:
                self._afficher_changement_mdp_force()
            else:
                self._afficher_menu()
        elif statut == "inactif":
            messagebox.showerror("Compte désactivé",
                                 "Votre compte a été désactivé.\nContactez un administrateur.")
        else:
            messagebox.showerror("Erreur", "Identifiants invalides.")

    def _deconnexion(self):
        self.user_nom  = None
        self.user_role = None
        self._afficher_demarrage()

    def _afficher_changement_mdp_force(self):
        self._clear()
        self._panel_gauche("Première connexion détectée.\nVous devez définir un nouveau\nmot de passe personnel.")

        form = tk.Frame(self.root, bg="#FFFFFF", width=480, height=560)
        form.pack(side="right", fill="both", expand=True)
        form.pack_propagate(False)

        tk.Label(form, text="Nouveau mot de passe.", fg="#1F2937", bg="#FFFFFF",
                 font=("Segoe UI", 20, "bold")).pack(anchor="w", padx=50, pady=(70, 8))
        tk.Label(form, text="Au moins 6 caractères.", fg="#6B7280", bg="#FFFFFF",
                 font=("Segoe UI", 10)).pack(anchor="w", padx=50, pady=(0, 20))

        self._lbl(form, "Nouveau mot de passe")
        f1, ent1 = self._champ(form, show="*")
        f1.pack(fill="x", padx=50, pady=(4, 16))

        self._lbl(form, "Confirmer le mot de passe")
        f2, ent2 = self._champ(form, show="*")
        f2.pack(fill="x", padx=50, pady=(4, 28))

        def valider():
            if ent1.get() != ent2.get():
                messagebox.showwarning("Erreur", "Les mots de passe ne correspondent pas.")
                return
            ok, msg = application.changer_mdp(self.user_nom, ent1.get())
            if ok:
                messagebox.showinfo("Succès", "Mot de passe mis à jour. Bienvenue !")
                self._afficher_menu()
            else:
                messagebox.showwarning("Erreur", msg)

        self._btn(form, "Valider", valider).pack(padx=50, fill="x", ipady=10)
        ent2.bind("<Return>", lambda e: valider())


    #  SHELL PRINCIPAL
    def _afficher_menu(self):
        self._clear()
        sidebar = tk.Frame(self.root, bg="#1A56DB", width=220, height=560)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        if self.logoMenu2:
            tk.Label(sidebar, image=self.logoMenu2, bg="#1A56DB").pack(pady=20)
        else:
            tk.Label(sidebar, text="HELHA.net", fg="white", bg="#1A56DB",
                     font=("Segoe UI", 14, "bold")).pack(pady=20)

        tk.Frame(sidebar, bg="#FFFFFF", height=1, width=180).pack(padx=20, pady=(0, 10))

        def nav(label, cmd):
            tk.Button(sidebar, text=label, bg="#1A56DB", fg="white",
                      relief="flat", anchor="w", padx=16, pady=10,
                      font=("Segoe UI", 10), activebackground="#1240A8",
                      cursor="hand2", command=cmd).pack(fill="x")

        nav("Tableau CIDR",          self._ouvrir_cidr)
        nav("Analyse IP",            self._ouvrir_analyse_ip)
        nav("Réseau / Sous-réseau",  self._ouvrir_classfull)
        nav("Même réseau ?",         self._ouvrir_meme_reseau)

        if self.user_role == "admin":
            tk.Frame(sidebar, bg="#FFFFFF", height=1, width=180).pack(padx=20, pady=10)
            nav("👥  Utilisateurs", self._ouvrir_gestion_users)

        bottom = tk.Frame(sidebar, bg="#1A56DB")
        bottom.pack(side="bottom", fill="x", pady=16)
        tk.Label(bottom, text=f"@{self.user_nom}", fg="#BAD0FB", bg="#1A56DB",
                 font=("Segoe UI", 9)).pack(anchor="w", padx=16)
        tk.Label(bottom, text=self.user_role.upper(), fg="#93C5FD", bg="#1A56DB",
                 font=("Segoe UI", 8)).pack(anchor="w", padx=16)
        tk.Button(bottom, text="Se déconnecter", bg="#1A56DB", fg="#FCA5A5",
                  relief="flat", anchor="w", padx=16, pady=8,
                  font=("Segoe UI", 10, "bold"), cursor="hand2",
                  command=self._deconnexion).pack(fill="x")

        self.zone = tk.Frame(self.root, bg="#F9FAFB", padx=36, pady=36)
        self.zone.pack(side="right", fill="both", expand=True)
        tk.Label(self.zone, text="Bienvenue 👋",
                 font=("Segoe UI", 22, "bold"), bg="#F9FAFB", fg="#1F2937").pack(anchor="w")
        tk.Label(self.zone, text=f"Connecté en tant que {self.user_nom} ({self.user_role})",
                 font=("Segoe UI", 11), bg="#F9FAFB", fg="#6B7280").pack(anchor="w", pady=(6, 0))


    #  OUTIL 1 — TABLEAU CIDR
    def _ouvrir_cidr(self):
        self._clear_zone()
        tk.Label(self.zone, text="Tableau des Masques CIDR",
                 font=("Segoe UI", 18, "bold"), bg="#F9FAFB", fg="#1F2937").pack(anchor="w", pady=(0, 16))
        cols = ("cidr", "binaire", "decimal")
        tab  = ttk.Treeview(self.zone, columns=cols, show="headings")
        tab.column("cidr",    width=50,  anchor="center", stretch=False)
        tab.column("binaire", width=310, anchor="center", stretch=True)
        tab.column("decimal", width=140, anchor="center", stretch=False)
        tab.heading("cidr",    text="CIDR")
        tab.heading("binaire", text="Masque Binaire")
        tab.heading("decimal", text="Décimal Pointé")
        for row in application.generer_donnees_cidr():
            tab.insert("", "end", values=row)
        tab.pack(fill="both", expand=True)


    #  OUTIL 2 — ANALYSE IP
    def _ouvrir_analyse_ip(self):
        self._clear_zone()
        tk.Label(self.zone, text="Analyse IP",
                 font=("Segoe UI", 18, "bold"), bg="#F9FAFB", fg="#1F2937").pack(anchor="w", pady=(0, 12))

        f, ent = self._champ(self.zone)
        f.pack(fill="x", pady=(0, 12))

        lbl_status = tk.Label(self.zone, text="", bg="#F9FAFB", font=("Segoe UI", 12, "bold"))
        lbl_status.pack(anchor="w")
        det = tk.Frame(self.zone, bg="#F9FAFB"); det.pack(anchor="w", pady=8)
        lbl_c = tk.Label(det, text="", bg="#F9FAFB", font=("Segoe UI", 11)); lbl_c.pack(anchor="w", pady=2)
        lbl_m = tk.Label(det, text="", bg="#F9FAFB", font=("Segoe UI", 11)); lbl_m.pack(anchor="w", pady=2)
        lbl_p = tk.Label(det, text="", bg="#F9FAFB", font=("Segoe UI", 11)); lbl_p.pack(anchor="w", pady=2)
        lbl_r = tk.Label(det, text="", bg="#F9FAFB", font=("Segoe UI", 11)); lbl_r.pack(anchor="w", pady=2)

        def check():
            ip = ent.get().strip()
            for l in [lbl_c, lbl_m, lbl_p, lbl_r]: l.config(text="")
            if not application.verifier_format_ip(ip):
                lbl_status.config(text="✘  IP invalide", fg="#EF4444"); return
            lbl_status.config(text="✔  IP valide", fg="#10B981")
            classe, masque = application.definir_classe(ip)
            lbl_c.config(text=f"• Classe           : {classe}")
            lbl_m.config(text=f"• Masque de classe : {masque}")
            prive = application.is_ip_privee(ip)
            lbl_p.config(text=f"• Type             : {'Adresse Privée' if prive else 'Adresse Publique'}",
                         fg="#D97706" if prive else "#2563EB")
            reservee, type_res = application.is_ip_reservee(ip)
            lbl_r.config(text=f"• Réservée         : {'Oui — ' + type_res if reservee else 'Non'}",
                         fg="#EF4444" if reservee else "#4B5563")

        self._btn(self.zone, "Analyser", check).pack(anchor="w", pady=(4, 0), ipadx=20, ipady=6)
        ent.bind("<Return>", lambda e: check())

    #  OUTIL 3 — RÉSEAU / SOUS-RÉSEAU (classful)
    def _ouvrir_classfull(self):
        self._clear_zone()
        tk.Label(self.zone, text="Réseau & Sous-réseau (Classful)",
                 font=("Segoe UI", 18, "bold"), bg="#F9FAFB", fg="#1F2937").pack(anchor="w", pady=(0, 16))

        def ligne(label, defaut):
            f = tk.Frame(self.zone, bg="#F9FAFB"); f.pack(fill="x", pady=4)
            tk.Label(f, text=label, width=12, anchor="w", bg="#F9FAFB",
                     font=("Segoe UI", 11)).pack(side="left")
            fb, e = self._champ(f, width=20)
            fb.pack(side="left")
            e.insert(0, defaut)
            return e

        ent_ip     = ligne("IP :",     "")
        ent_masque = ligne("Masque :", "")

        lbl_err   = tk.Label(self.zone, text="", bg="#F9FAFB", font=("Segoe UI", 11, "bold"))
        lbl_err.pack(anchor="w", pady=(8, 0))
        res_frame = tk.Frame(self.zone, bg="#F9FAFB"); res_frame.pack(anchor="w", pady=4)

        def calc():
            for w in res_frame.winfo_children(): w.destroy()
            lbl_err.config(text="")
            ip     = ent_ip.get().strip()
            masque = ent_masque.get().strip()
            if not application.verifier_format_ip(ip):
                lbl_err.config(text="✘  IP invalide", fg="#EF4444"); return
            if not application.verifier_format_masque(masque):
                lbl_err.config(text="✘  Masque invalide", fg="#EF4444"); return

            r = application.calculer_reseau_classfull(ip, masque)
            infos = [
                ("Classe",           r["classe"]),
                ("Masque de classe", r["masque_classe"]),
                ("Réseau classful",  r["reseau_classe"]),
                ("",                 ""),
                ("Masque appliqué",  f"{r['masque']}  (/{r['cidr']})"),
                ("Adresse réseau",   r["reseau"]),
                ("Broadcast",        r["broadcast"]),
                ("1ère hôte",        r["premiere_hote"]),
                ("Dernière hôte",    r["derniere_hote"]),
                ("Nb hôtes",         str(r["nb_hotes"])),
            ]
            for label, valeur in infos:
                if label == "":
                    tk.Frame(res_frame, bg="#E5E7EB", height=1).pack(fill="x", pady=4)
                    continue
                row = tk.Frame(res_frame, bg="#F9FAFB"); row.pack(anchor="w", pady=1)
                tk.Label(row, text=f"• {label}", bg="#F9FAFB", fg="#6B7280",
                         font=("Segoe UI", 10), width=22, anchor="w").pack(side="left")
                tk.Label(row, text=valeur, bg="#F9FAFB", fg="#1F2937",
                         font=("Segoe UI", 10, "bold")).pack(side="left")

        self._btn(self.zone, "Calculer", calc).pack(anchor="w", pady=(4, 0), ipadx=20, ipady=6)
        ent_masque.bind("<Return>", lambda e: calc())

    #  OUTIL 4 — MÊME RÉSEAU ?
    def _ouvrir_meme_reseau(self):
        self._clear_zone()
        tk.Label(self.zone, text="Deux IP dans le même réseau ?",
                 font=("Segoe UI", 18, "bold"), bg="#F9FAFB", fg="#1F2937").pack(anchor="w", pady=(0, 16))

        def ligne(label, defaut):
            f = tk.Frame(self.zone, bg="#F9FAFB"); f.pack(fill="x", pady=4)
            tk.Label(f, text=label, width=9, anchor="w", bg="#F9FAFB",
                     font=("Segoe UI", 11)).pack(side="left")
            fb, e = self._champ(f, width=18)
            fb.pack(side="left")
            e.insert(0, defaut)
            return e

        ent_ip1  = ligne("IP 1 :",  "")
        ent_ip2  = ligne("IP 2 :",  "")
        ent_cidr = ligne("CIDR :",  "")

        lbl_res   = tk.Label(self.zone, text="", font=("Segoe UI", 13, "bold"), bg="#F9FAFB")
        lbl_res.pack(anchor="w", pady=(14, 4))
        det_frame = tk.Frame(self.zone, bg="#F9FAFB"); det_frame.pack(anchor="w")

        def calc():
            for w in det_frame.winfo_children(): w.destroy()
            ip1 = ent_ip1.get().strip()
            ip2 = ent_ip2.get().strip()
            try:
                cidr = int(ent_cidr.get().strip())
                assert 0 <= cidr <= 32
            except Exception:
                lbl_res.config(text="CIDR invalide (0–32)", fg="#EF4444"); return
            if not application.verifier_format_ip(ip1):
                lbl_res.config(text="IP 1 invalide", fg="#EF4444"); return
            if not application.verifier_format_ip(ip2):
                lbl_res.config(text="IP 2 invalide", fg="#EF4444"); return

            r = application.meme_reseau(ip1, ip2, cidr)
            if r["meme_reseau"]:
                lbl_res.config(text="✔  Même réseau", fg="#10B981")
            else:
                lbl_res.config(text="✘  Réseaux différents", fg="#EF4444")

            for label, valeur in [
                ("Masque",      r["masque"]),
                ("Réseau IP 1", r["reseau_ip1"] + f" /{cidr}"),
                ("Réseau IP 2", r["reseau_ip2"] + f" /{cidr}"),
                ("Broadcast",   r["broadcast"]),
            ]:
                row = tk.Frame(det_frame, bg="#F9FAFB"); row.pack(anchor="w", pady=1)
                tk.Label(row, text=f"• {label:<16}", bg="#F9FAFB", fg="#6B7280",
                         font=("Segoe UI", 10), width=20, anchor="w").pack(side="left")
                tk.Label(row, text=valeur, bg="#F9FAFB", fg="#1F2937",
                         font=("Segoe UI", 10, "bold")).pack(side="left")

        self._btn(self.zone, "Comparer", calc).pack(anchor="w", pady=(4, 0), ipadx=20, ipady=6)
        ent_cidr.bind("<Return>", lambda e: calc())


    #  OUTIL 5 — GESTION UTILISATEURS (admin)
    def _ouvrir_gestion_users(self):
        if self.user_role != "admin":
            return
        self._clear_zone()

        hdr = tk.Frame(self.zone, bg="#F9FAFB"); hdr.pack(fill="x", pady=(0, 12))
        tk.Label(hdr, text="Gestion des utilisateurs",
                 font=("Segoe UI", 18, "bold"), bg="#F9FAFB", fg="#1F2937").pack(side="left")
        self._btn(hdr, "+ Créer", self._popup_creer_user,
                  couleur="#10B981").pack(side="right", ipadx=10, ipady=4)

        cols = ("nom", "role", "etat")
        self.tree = ttk.Treeview(self.zone, columns=cols, show="headings", height=12)
        self.tree.column("nom",  width=200, anchor="w")
        self.tree.column("role", width=100, anchor="center")
        self.tree.column("etat", width=120, anchor="center")
        self.tree.heading("nom",  text="Nom d'utilisateur")
        self.tree.heading("role", text="Rôle")
        self.tree.heading("etat", text="État")
        self.tree.pack(fill="both", expand=True)
        self.tree.tag_configure("inactif", foreground="#9CA3AF")
        self.tree.tag_configure("admin",   foreground="#1A56DB")

        act = tk.Frame(self.zone, bg="#F9FAFB"); act.pack(fill="x", pady=(10, 0))
        self._btn(act, "🔄 Changer rôle",        self._changer_role,
                  couleur="#6366F1").pack(side="left", padx=(0, 6), ipadx=8, ipady=4)
        self._btn(act, "⏸ Activer / Désactiver", self._basculer,
                  couleur="#F59E0B").pack(side="left", padx=6, ipadx=8, ipady=4)

        self._rafraichir_users()

    def _rafraichir_users(self):
        for r in self.tree.get_children():
            self.tree.delete(r)
        for u in application.lire_utilisateurs():
            etat = "✔ Actif" if u["actif"] else "✘ Désactivé"
            tag  = "inactif" if not u["actif"] else ("admin" if u["role"] == "admin" else "")
            self.tree.insert("", "end", values=(u["nom"], u["role"], etat), tags=(tag,))

    def _selection(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Sélection", "Sélectionnez un utilisateur dans le tableau.")
            return None
        return self.tree.item(sel[0])["values"][0]

    def _popup_creer_user(self):
        win = tk.Toplevel(self.root)
        win.title("Créer un utilisateur")
        win.geometry("400x280")
        win.configure(bg="#FFFFFF")
        win.resizable(False, False)
        win.grab_set()

        tk.Label(win, text="Créer un utilisateur",
                 font=("Segoe UI", 15, "bold"), bg="#FFFFFF", fg="#1F2937").pack(padx=30, pady=(24, 12), anchor="w")
        tk.Label(win, text="Nom d'utilisateur", bg="#FFFFFF", fg="#6B7280",
                 font=("Segoe UI", 10)).pack(anchor="w", padx=30)
        fb, ent_nom = self._champ(win)
        fb.pack(fill="x", padx=30, pady=(4, 16))

        tk.Label(win, text="Rôle", bg="#FFFFFF", fg="#6B7280",
                 font=("Segoe UI", 10)).pack(anchor="w", padx=30)
        role_var = tk.StringVar(value="user")
        fr = tk.Frame(win, bg="#FFFFFF"); fr.pack(anchor="w", padx=30, pady=(4, 20))
        tk.Radiobutton(fr, text="Utilisateur", variable=role_var, value="user",
                       bg="#FFFFFF", font=("Segoe UI", 10)).pack(side="left", padx=(0, 16))
        tk.Radiobutton(fr, text="Admin", variable=role_var, value="admin",
                       bg="#FFFFFF", font=("Segoe UI", 10)).pack(side="left")

        def valider():
            ok, resultat = application.creer_utilisateur(ent_nom.get(), role_var.get())
            if ok:
                self._popup_mdp_oneshot(ent_nom.get(), resultat, win)
            else:
                messagebox.showwarning("Erreur", resultat, parent=win)

        self._btn(win, "Créer & générer MDP", valider).pack(padx=30, fill="x", ipady=8)

    def _popup_mdp_oneshot(self, nom, mdp_tmp, parent=None):
        win = tk.Toplevel(self.root)
        win.title("Mot de passe temporaire")
        win.geometry("400x230")
        win.configure(bg="#FFFFFF")
        win.resizable(False, False)
        win.grab_set()
        if parent:
            try: parent.destroy()
            except Exception: pass

        tk.Label(win, text="⚠  Mot de passe temporaire",
                 font=("Segoe UI", 13, "bold"), bg="#FFFFFF", fg="#D97706").pack(pady=(28, 6))
        tk.Label(win, text=f"Compte : {nom}",
                 bg="#FFFFFF", fg="#6B7280", font=("Segoe UI", 10)).pack()
        tk.Label(win, text="Transmettez-le à l'utilisateur.\nIl devra le changer à la première connexion.",
                 bg="#FFFFFF", fg="#6B7280", font=("Segoe UI", 9), justify="center").pack(pady=(4, 10))
        box = tk.Frame(win, bg="#F3F4F6", padx=16, pady=10)
        box.pack(padx=40, fill="x")
        tk.Label(box, text=mdp_tmp, font=("Courier", 16, "bold"),
                 bg="#F3F4F6", fg="#1F2937").pack()

        def fermer():
            win.destroy()
            self._rafraichir_users()

        self._btn(win, "J'ai noté, fermer", fermer).pack(pady=14, ipadx=20, ipady=6)

    def _changer_role(self):
        nom = self._selection()
        if not nom: return
        utilisateurs = application.lire_utilisateurs()
        role_actuel  = next((u["role"] for u in utilisateurs if u["nom"] == nom), "user")
        nouveau      = "user" if role_actuel == "admin" else "admin"
        if not messagebox.askyesno("Confirmation",
                                   f"Changer le rôle de « {nom} » : {role_actuel} → {nouveau} ?"):
            return
        ok, msg = application.changer_role(nom, nouveau)
        if ok: messagebox.showinfo("Succès", msg); self._rafraichir_users()
        else:  messagebox.showerror("Erreur", msg)

    def _basculer(self):
        nom = self._selection()
        if not nom: return
        utilisateurs = application.lire_utilisateurs()
        etat_actuel  = next((u["actif"] for u in utilisateurs if u["nom"] == nom), True)
        verbe        = "désactiver" if etat_actuel else "réactiver"
        if not messagebox.askyesno("Confirmation",
                                   f"Voulez-vous {verbe} le compte « {nom} » ?\n"
                                   "Le compte sera conservé en base de données."):
            return
        ok, msg = application.basculer_activation(nom, self.user_nom)
        if ok: messagebox.showinfo("Succès", msg); self._rafraichir_users()
        else:  messagebox.showerror("Erreur", msg)


if __name__ == "__main__":
    root = tk.Tk()
    AppHelha(root)
    root.mainloop()