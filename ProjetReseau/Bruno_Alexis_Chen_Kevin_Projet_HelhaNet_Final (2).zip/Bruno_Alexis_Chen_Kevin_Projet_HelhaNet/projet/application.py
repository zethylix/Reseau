import bcrypt
import os
import secrets
import string

# ─────────────────────────────────────────────
#  CHEMINS
# ─────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, "DB.txt")

# Format DB : nom;hash;role;must_change;actif
# must_change : 1 = doit changer son MDP à la prochaine connexion
# actif       : 1 = actif, 0 = désactivé (gardé en DB)


# ─────────────────────────────────────────────
#  MOT DE PASSE
# ─────────────────────────────────────────────
def hash_mdp(mdp: str) -> bytes:
    return bcrypt.hashpw(mdp.encode(), bcrypt.gensalt(rounds=12))

def verifier_mdp(mdp: str, hash_stocke: str) -> bool:
    return bcrypt.checkpw(mdp.encode(), hash_stocke.encode())

def generer_mdp_temporaire() -> str:
    """MDP simple lisible 8 chars — affiché une seule fois à l'admin."""
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(8))


# ─────────────────────────────────────────────
#  LECTURE / ÉCRITURE DB
# ─────────────────────────────────────────────
def lire_utilisateurs() -> list:
    utilisateurs = []
    if not os.path.exists(DB_PATH):
        return utilisateurs
    with open(DB_PATH, 'r', encoding='utf-8') as f:
        for ligne in f:
            ligne = ligne.strip()
            if not ligne:
                continue
            parts = ligne.split(";")
            if len(parts) == 3:          # rétrocompatibilité ancien format
                parts += ["1", "1"]
            if len(parts) == 5:
                utilisateurs.append({
                    "nom":         parts[0],
                    "hash":        parts[1],
                    "role":        parts[2],
                    "must_change": parts[3] == "1",
                    "actif":       parts[4] == "1",
                })
    return utilisateurs

def ecrire_utilisateurs(utilisateurs: list):
    with open(DB_PATH, 'w', encoding='utf-8') as f:
        for u in utilisateurs:
            mc  = "1" if u.get("must_change") else "0"
            act = "1" if u.get("actif", True) else "0"
            f.write(f"{u['nom']};{u['hash']};{u['role']};{mc};{act}\n")


# ─────────────────────────────────────────────
#  GESTION UTILISATEURS
# ─────────────────────────────────────────────
def utilisateur_existe(nom: str) -> bool:
    return any(u["nom"] == nom for u in lire_utilisateurs())

def creer_utilisateur(nom: str, role: str):
    """
    Crée un utilisateur avec MDP temporaire auto-généré.
    Retourne (True, mdp_en_clair) ou (False, message_erreur).
    must_change=True force le changement à la première connexion.
    """
    nom = nom.strip()
    if not nom:
        return False, "Le nom d'utilisateur est obligatoire."
    if utilisateur_existe(nom):
        return False, f"L'utilisateur « {nom} » existe déjà."
    if role not in ("admin", "user"):
        return False, "Rôle invalide."
    mdp_tmp = generer_mdp_temporaire()
    utilisateurs = lire_utilisateurs()
    utilisateurs.append({
        "nom":         nom,
        "hash":        hash_mdp(mdp_tmp).decode(),
        "role":        role,
        "must_change": True,
        "actif":       True,
    })
    ecrire_utilisateurs(utilisateurs)
    return True, mdp_tmp

def changer_mdp(nom: str, nouveau_mdp: str):
    if len(nouveau_mdp) < 6:
        return False, "Le mot de passe doit faire au moins 6 caractères."
    utilisateurs = lire_utilisateurs()
    for u in utilisateurs:
        if u["nom"] == nom:
            u["hash"]        = hash_mdp(nouveau_mdp).decode()
            u["must_change"] = False
            ecrire_utilisateurs(utilisateurs)
            return True, "Mot de passe changé avec succès."
    return False, "Utilisateur introuvable."

def basculer_activation(nom_cible: str, nom_actuel: str):
    """Active ou désactive un compte — le garde en DB dans tous les cas."""
    if nom_cible == nom_actuel:
        return False, "Vous ne pouvez pas désactiver votre propre compte."
    utilisateurs = lire_utilisateurs()
    for u in utilisateurs:
        if u["nom"] == nom_cible:
            u["actif"] = not u["actif"]
            ecrire_utilisateurs(utilisateurs)
            etat = "activé" if u["actif"] else "désactivé"
            return True, f"Compte « {nom_cible} » {etat}."
    return False, "Utilisateur introuvable."

def changer_role(nom_cible: str, nouveau_role: str):
    utilisateurs = lire_utilisateurs()
    admins = [u for u in utilisateurs if u["role"] == "admin" and u["actif"]]
    for u in utilisateurs:
        if u["nom"] == nom_cible:
            if u["role"] == "admin" and len(admins) == 1 and nouveau_role != "admin":
                return False, "Impossible : dernier administrateur actif."
            u["role"] = nouveau_role
            ecrire_utilisateurs(utilisateurs)
            return True, f"Rôle de « {nom_cible} » changé en {nouveau_role}."
    return False, "Utilisateur introuvable."

def reinitialiser_mdp(nom_cible: str):
    """Génère un nouveau MDP temporaire et force le changement à la prochaine connexion."""
    utilisateurs = lire_utilisateurs()
    for u in utilisateurs:
        if u["nom"] == nom_cible:
            mdp_tmp      = generer_mdp_temporaire()
            u["hash"]        = hash_mdp(mdp_tmp).decode()
            u["must_change"] = True
            ecrire_utilisateurs(utilisateurs)
            return True, mdp_tmp
    return False, "Utilisateur introuvable."


# ─────────────────────────────────────────────
#  AUTHENTIFICATION
# ─────────────────────────────────────────────
def connexion(nom: str, mdp: str):
    """
    Retourne (statut, role, must_change).
    statut : 'ok' | 'inactif' | 'erreur'
    """
    for u in lire_utilisateurs():
        if u["nom"] == nom and verifier_mdp(mdp, u["hash"]):
            if not u["actif"]:
                return "inactif", None, False
            return "ok", u["role"], u["must_change"]
    return "erreur", None, False

def est_premier_lancement() -> bool:
    if not os.path.exists(DB_PATH) or os.path.getsize(DB_PATH) == 0:
        return True
    with open(DB_PATH, encoding='utf-8') as f:
        return all(not l.strip() for l in f)

def sauvegarde_admin_initial(nom: str, mdp: str):
    ecrire_utilisateurs([{
        "nom":         nom,
        "hash":        hash_mdp(mdp).decode(),
        "role":        "admin",
        "must_change": False,
        "actif":       True,
    }])


# ─────────────────────────────────────────────
#  OUTILS RÉSEAU
# ─────────────────────────────────────────────
def generer_donnees_cidr() -> list:
    donnees = []
    for i in range(8, 31):
        bits = '1' * i + '0' * (32 - i)
        octets_bin = [bits[j:j+8] for j in range(0, 32, 8)]
        octets_dec = [str(int(o, 2)) for o in octets_bin]
        donnees.append((f"/{i}", ".".join(octets_bin), ".".join(octets_dec)))
    return donnees

def verifier_format_ip(ip: str) -> bool:
    parties = ip.strip().split('.')
    if len(parties) != 4:
        return False
    try:
        return all(0 <= int(p) <= 255 for p in parties)
    except ValueError:
        return False

def definir_classe(ip: str):
    premier = int(ip.split('.')[0])
    if 1 <= premier <= 126:   return "A", "255.0.0.0"
    if premier == 127:        return "Boucle locale (A)", "255.0.0.0"
    if 128 <= premier <= 191: return "B", "255.255.0.0"
    if 192 <= premier <= 223: return "C", "255.255.255.0"
    if 224 <= premier <= 239: return "D", "Non applicable (Multicast)"
    return "E", "Non applicable (Expérimental)"

def is_ip_privee(ip: str) -> bool:
    o = [int(p) for p in ip.split('.')]
    return (o[0] == 10) or \
           (o[0] == 172 and 16 <= o[1] <= 31) or \
           (o[0] == 192 and o[1] == 168)

def is_ip_reservee(ip: str):
    o = [int(p) for p in ip.split('.')]
    if o[0] == 0:                       return True, "Réseau courant (This network)"
    if o[0] == 127:                     return True, "Boucle locale (Loopback)"
    if o[0] == 169 and o[1] == 254:     return True, "APIPA (Link-local)"
    if o == [255, 255, 255, 255]:       return True, "Broadcast global"
    return False, ""

def masque_cidr_vers_decimal(cidr: int) -> str:
    bits = '1' * cidr + '0' * (32 - cidr)
    return ".".join(str(int(bits[i:i+8], 2)) for i in range(0, 32, 8))

def ip_vers_entier(ip: str) -> int:
    o = [int(p) for p in ip.split('.')]
    return (o[0] << 24) | (o[1] << 16) | (o[2] << 8) | o[3]

def meme_reseau(ip1: str, ip2: str, cidr: int) -> dict:
    masque_int  = (0xFFFFFFFF << (32 - cidr)) & 0xFFFFFFFF
    int1        = ip_vers_entier(ip1)
    int2        = ip_vers_entier(ip2)
    reseau1_int = int1 & masque_int
    reseau2_int = int2 & masque_int
    def int_vers_ip(n):
        return ".".join(str((n >> s) & 0xFF) for s in (24, 16, 8, 0))
    broadcast_int = reseau1_int | (~masque_int & 0xFFFFFFFF)
    return {
        "masque":      masque_cidr_vers_decimal(cidr),
        "reseau_ip1":  int_vers_ip(reseau1_int),
        "reseau_ip2":  int_vers_ip(reseau2_int),
        "broadcast":   int_vers_ip(broadcast_int),
        "meme_reseau": reseau1_int == reseau2_int,
    }

def calculer_reseau_classfull(ip: str, masque: str) -> dict:

    def ip_vers_entier(ip):
        o = [int(p) for p in ip.split('.')]
        return (o[0] << 24) | (o[1] << 16) | (o[2] << 8) | o[3]

    def entier_vers_ip(n):
        return ".".join(str((n >> s) & 0xFF) for s in (24, 16, 8, 0))

    def masque_vers_cidr(masque_int):
        bits = bin(masque_int)[2:].zfill(32)
        return bits.count('1')

    ip_int     = ip_vers_entier(ip)
    masque_int = ip_vers_entier(masque)

    # Adresse réseau = IP AND masque
    reseau_int     = ip_int & masque_int
    # Broadcast = réseau OR (NOT masque)
    broadcast_int  = reseau_int | (~masque_int & 0xFFFFFFFF)

    # Masque de classe naturel (classfull)
    premier = (ip_int >> 24) & 0xFF
    if 1 <= premier <= 126:
        masque_classe_int = ip_vers_entier("255.0.0.0")
        classe = "A"
    elif 128 <= premier <= 191:
        masque_classe_int = ip_vers_entier("255.255.0.0")
        classe = "B"
    elif 192 <= premier <= 223:
        masque_classe_int = ip_vers_entier("255.255.255.0")
        classe = "C"
    else:
        masque_classe_int = masque_int
        classe = "D/E"

    # Adresse réseau classful
    reseau_classe_int = ip_int & masque_classe_int

    # Nombre d'hôtes
    nb_bits_hotes = 32 - masque_vers_cidr(masque_int)
    nb_hotes = max(0, (2 ** nb_bits_hotes) - 2)

    return {
        "ip":              ip,
        "masque":          masque,
        "cidr":            masque_vers_cidr(masque_int),
        "classe":          classe,
        "masque_classe":   entier_vers_ip(masque_classe_int),
        "reseau_classe":   entier_vers_ip(reseau_classe_int),
        "reseau":          entier_vers_ip(reseau_int),
        "broadcast":       entier_vers_ip(broadcast_int),
        "premiere_hote":   entier_vers_ip(reseau_int + 1),
        "derniere_hote":   entier_vers_ip(broadcast_int - 1),
        "nb_hotes":        nb_hotes,
    }

def verifier_format_masque(masque: str) -> bool:
    """Vérifie qu'un masque est valide (suite de 1 puis de 0 en binaire)."""
    if not verifier_format_ip(masque):
        return False
    o = [int(p) for p in masque.split('.')]
    val = (o[0] << 24) | (o[1] << 16) | (o[2] << 8) | o[3]
    bits = bin(val)[2:].zfill(32)
    # Un masque valide : tous les 1 sont avant tous les 0
    return '01' not in bits